import streamlit as st
import streamlit.components.v1 as components
import os

# Set full page config
st.set_page_config(page_title="TravelSage", layout="wide")

# Title
st.markdown("<h1 style='text-align: center; color: #4CAF50;'>🌍 Welcome to TravelSage</h1>", unsafe_allow_html=True)

# Module definitions
modules = [
    {"name": "Tourist Places", "image": "pages/Data/Places/Tourist.png", "file": "pages/Data/Places/spots/places.html"},
    {"name": "Local Laws", "image": "pages/Data/Rules/Rules.png", "file": "pages/Data/Rules/rules.html"},
    {"name": "Translator", "image": "pages/Data/Translator/Translator.png", "file": "pages/Data/Translator/translator.html"},
    {"name": "Map", "image": "pages/Data/Map/Map.png", "file": "pages/Data/Map/map.html"},
    {"name": "History", "image": "pages/Data/History/Historical.png", "file": "pages/Data/History/history.html"},
    {"name": "Local Dishes", "image": "pages/Data/Recipes/Recipes.png", "file": "pages/Data/Recipes/recipes.html"},
    {"name": "Currency Converter", "image": "pages/Data/CC/CC.png", "file": "pages/Data/CC/cc.html"},
    {"name": "Chat Bot", "image": "pages/Data/Bot/Chatbot.png", "file": "pages/Data/Bot/chatbot.html"},
]

# Session state for navigation
if "page" not in st.session_state:
    st.session_state.page = "home"

# Home page layout
def home():
    st.markdown("## 🧭 Explore Modules")
    st.markdown("Click any module to explore:")

    for i in range(0, len(modules), 4):
        cols = st.columns(4)
        for j in range(4):
            if i + j < len(modules):
                module = modules[i + j]
                with cols[j]:
                    st.markdown("### " + module["name"], unsafe_allow_html=True)
                    if os.path.exists(module["image"]):
                        st.image(module["image"], use_container_width=True)
                    if st.button("Open", key=module["name"]):
                        st.session_state.page = module["name"]

# Display selected module's HTML

def show_html_module(module):
    st.markdown(f"## 📘 {module['name']}")
    if module["file"].startswith("http"):
        components.iframe(module["file"], height=700, scrolling=True)
    else:
        if os.path.exists(module["file"]):
            with open(module["file"], "r", encoding="utf-8") as f:
                html_content = f.read()
            components.html(html_content, height=700, scrolling=True)
        else:
            st.error("Module HTML file not found.")
    if st.button("⬅ Back to Home"):
        st.session_state.page = "home"



# Navigation
if st.session_state.page == "home":
    home()
else:
    current = next((m for m in modules if m["name"] == st.session_state.page), None)
    if current:
        show_html_module(current)
    else:
        st.error("Invalid module selected.")

# Custom CSS for full-screen feel
st.markdown("""
    <style>
    .stButton > button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 24px;
        font-size: 16px;
        margin-top: 10px;
        border-radius: 8px;
        width: 100%;
    }
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
    </style>
""", unsafe_allow_html=True)
