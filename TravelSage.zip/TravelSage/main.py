import streamlit as st
import base64
import os

st.set_page_config(page_title="TravelSage", layout="wide")

def render_video(video_path):
    with open(video_path, "rb") as f:
        video_bytes = f.read()
        encoded = base64.b64encode(video_bytes).decode()

    st.markdown(f"""
        <div class='video-container'>
            <video autoplay muted loop playsinline class='video-background'>
                <source src="data:video/mp4;base64,{encoded}" type="video/mp4">
            </video>
            <div class='overlay'>
                <h1 class='main-title'>Welcome to TravelSage 🌍</h1>
                <p class='main-subtitle'>Your All Time Travel Companion</p>
            </div>
        </div>
        <style>
            html, body, .stApp {{
                margin: 0;
                padding: 0;
                height: 100%;
                font-family: 'Poppins', sans-serif;
                background-color: black;
            }}
            .video-container {{
                position: relative;
                height: 100vh;
                overflow: hidden;
            }}
            .video-background {{
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                object-fit: cover;
                z-index: -1;
            }}
            .overlay {{
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                color: white;
                text-align: center;
            }}
            .main-title {{
                font-size: 3.5rem;
            }}
            .main-subtitle {{
                font-size: 1.4rem;
                margin-top: 10px;
            }}
        </style>
    """, unsafe_allow_html=True)

# Video rendering
video_path = os.path.join("pages","assets", "images", "aniv.mp4")
if os.path.exists(video_path):
    render_video(video_path)
else:
    st.error("Video file not found.")

# ✅ Streamlit native button that navigates
if st.button("Get Started"):
    st.switch_page("pages/explore.py")  # Must match the filename
